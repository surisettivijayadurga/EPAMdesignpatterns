package com.epam.factorypattern;

public class Windows implements Os {

	@Override
	public void spec() {
		System.out.println("Windows");
		
	}

}
