package com.epam.factorypattern;

public class Android implements Os {
	public void spec() {
		System.out.println("Android");
	}

}
