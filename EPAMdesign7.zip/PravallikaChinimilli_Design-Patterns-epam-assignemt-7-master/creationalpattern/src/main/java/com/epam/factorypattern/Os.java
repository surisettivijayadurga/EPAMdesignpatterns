package com.epam.factorypattern;

public interface Os {
	void spec();

}
