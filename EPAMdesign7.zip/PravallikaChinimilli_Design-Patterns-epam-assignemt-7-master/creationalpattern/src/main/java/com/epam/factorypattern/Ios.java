package com.epam.factorypattern;

public class Ios implements Os {
	

	@Override
	public void spec() {
		// TODO Auto-generated method stub
		System.out.println("Ios");
		
	}

}
