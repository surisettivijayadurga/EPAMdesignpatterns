package com.epam.creationalpattern;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Singleton obj1=Singleton.getInstance();
        obj1.run();
        
    }
}
